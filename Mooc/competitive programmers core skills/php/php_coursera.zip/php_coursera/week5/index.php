<title>Zishnendu Sarker PHP</title>
<h1>Zishnendu Sarker PHP</h1>
<p><?php
	print "The SHA256 hash of \"Zishnendu Sarker\" is ".hash('sha256', 'Zishnendu Sarker');
?></p>
<pre>ASCII ART:
    ********
         **
        **
       **
      **
     **
    ********
</pre>
<a href="fail.php">Click here to check the error setting</a>
<br>
<a href="check.php">Click here to cause a traceback</a>
