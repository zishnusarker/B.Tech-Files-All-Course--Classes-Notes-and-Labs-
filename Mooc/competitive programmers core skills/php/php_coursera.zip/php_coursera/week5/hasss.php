
<title>Anamitra Musib PHP</title>
<h1>Anamitra Musib PHP</h1>
<p><?php
	print "The SHA256 hash of \"Anamitra Musib\" is ".hash('sha256', 'Anamitra Musib');
?></p>
<pre>ASCII ART:
     *******
         **
        **
       **
      **
     **
    *******
</pre>
<a href="fail.php">Click here to check the error setting</a>
<br>
<a href="check.php">Click here to cause a traceback</a>
